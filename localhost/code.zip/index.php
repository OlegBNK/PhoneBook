<?php

//abstract class Identifiable
//{
//    protected $id;
//
//    public function getId()
//    {
//        return $this->id;
//    }
//
//    public function setId($id): void
//    {
//        $this->id = $id;
//    }
//}
//class Language extends Identifiable
//{
//
//}
//class Education
//{
//
//}
//class User extends Identifiable
//{
//
//}

//$education = new Education();
//$education->setId(1);

//echo "<pre>";
//var_dump($education);
//echo "</pre>";

//abstract class Article extends Identifiable
//{
//    protected $title;
//    protected $counter;
//    protected $description;
//
//    /**
//     * @return mixed
//     */
//    public function getTitle()
//    {
//        return $this->title;
//    }
//
//    /**
//     * @param mixed $title
//     */
//    public function setTitle($title): void
//    {
//        $this->title = $title;
//    }
//
//    /**
//     * @return mixed
//     */
//    public function getCounter()
//    {
//        return $this->counter;
//    }
//
//    /**
//     * @param mixed $counter
//     */
//    public function setCounter($counter): void
//    {
//        $this->counter = $counter;
//    }
//
//    /**
//     * @return mixed
//     */
//    public function getDescription()
//    {
//        return $this->description;
//    }
//
//    /**
//     * @param mixed $description
//     */
//    public function setDescription($description): void
//    {
//        $this->description = $description;
//    }
//}
//
//final class TextArticle extends Article
//{
//    protected $text;
//
//    public function getText()
//    {
//        return $this->text;
//    }
//
//    public function setText($text): void
//    {
//        $this->text = $text;
//    }
//}
//
//final class ImageArticle extends Article
//{
//    protected $thumbnail;
//    protected $image;
//
//    /**
//     * @return mixed
//     */
//    public function getThumbnail()
//    {
//        return $this->thumbnail;
//    }
//
//    /**
//     * @param mixed $thumbnail
//     */
//    public function setThumbnail($thumbnail): void
//    {
//        $this->thumbnail = $thumbnail;
//    }
//
//    /**
//     * @return mixed
//     */
//    public function getImage()
//    {
//        return $this->image;
//    }
//
//    /**
//     * @param mixed $image
//     */
//    public function setImage($image): void
//    {
//        $this->image = $image;
//    }
//}
//
//final class AudioArticle extends Article
//{
//    protected $audioUrl;
//
//    /**
//     * @return mixed
//     */
//    public function getAudioUrl()
//    {
//        return $this->audioUrl;
//    }
//
//    /**
//     * @param mixed $audioUrl
//     */
//    public function setAudioUrl($audioUrl): void
//    {
//        $this->audioUrl = $audioUrl;
//    }
//}
//
//final class VideoArticle extends Article
//{
//    protected $videoUrl;
//
//    /**
//     * @return mixed
//     */
//    public function getVideoUrl()
//    {
//        return $this->videoUrl;
//    }
//
//    /**
//     * @param mixed $videoUrl
//     */
//    public function setVideoUrl($videoUrl): void
//    {
//        $this->videoUrl = $videoUrl;
//    }
//}
//
//$textArticle = new TextArticle();
//$textArticle->setId(1);
//$textArticle->setTitle('My text article');
//$textArticle->setCounter(0);
//$textArticle->setDescription('Some seo description');
//$textArticle->setText('Article text');
//
//$videoArticle = new VideoArticle();
//$videoArticle->setId(1);
//$videoArticle->setTitle('My text article');
//$videoArticle->setCounter(0);
//$videoArticle->setDescription('Some seo description');
//$videoArticle->setVideoUrl('http://saokpokasdpoka.mpeg');
