<?php

interface AdministratorInterface extends AuthorInterface, WriterInterface
{
    public function ban();
    public function unban();
}