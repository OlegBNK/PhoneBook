<?php

class Administrator implements AdministratorInterface
{
    use WritebleArticleTrait;
    use ManagebleArticleTrait;

    public function ban()
    {
        // TODO: Implement ban() method.
    }

    public function unban()
    {
        // TODO: Implement unban() method.
    }
}