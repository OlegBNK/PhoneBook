<?php
/**
 * Created by PhpStorm.
 * User: stanislas
 * Date: 24.10.18
 * Time: 21:04
 */

class Author implements AuthorInterface
{
    use ManagebleArticleTrait;
}
