<?php

interface WriterInterface
{
    public function writeArticle();
}