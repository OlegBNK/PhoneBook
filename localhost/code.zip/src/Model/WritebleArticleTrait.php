<?php

trait WritebleArticleTrait
{
    public function writeArticle()
    {
        // TODO: Implement writeArticle() method.
    }
}