<?php
/**
 * Created by PhpStorm.
 * User: stanislas
 * Date: 24.10.18
 * Time: 21:07
 */

trait ManagebleArticleTrait
{
    public function publish()
    {
        // TODO: Implement publish() method.
    }

    public function unpublish()
    {
        // TODO: Implement unpublish() method.
    }
}