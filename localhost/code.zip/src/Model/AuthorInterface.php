<?php

interface AuthorInterface
{
    public function publish();
    public function unpublish();
}