<?php

class Writer implements WriterInterface
{
    use WritebleArticleTrait;
}