<?php

namespace Hillel\Model;

trait WritableArticleTrait
{
    public function writeArticle()
    {

    }
}
