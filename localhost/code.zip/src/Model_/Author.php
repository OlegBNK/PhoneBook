<?php

namespace Hillel\Model;

final class Author extends User
{
    use WritableArticleTrait;
}