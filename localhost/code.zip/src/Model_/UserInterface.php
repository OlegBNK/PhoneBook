<?php

namespace Hillel\Model;

interface UserInterface
{
    public function getEmail();
    public function setEmail($email): void;

    public function getPassword();
    public function setPassword($password): void;

    public function getCreatedAt();
    public function setCreatedAt($createdAt): void;

    public function setUpdatedAt($updatedAt): void;
    public function getUpdatedAt();

    public function setDeletedAt($deletedAt): void;
    public function getDeletedAt();
}