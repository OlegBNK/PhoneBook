<?php

namespace Hillel\Model;

abstract class Identifiable
{
    protected $id;

    public function getId()
    {
        return $this->id;
    }

    public function setId($id): void
    {
        $this->id = $id;
    }
}