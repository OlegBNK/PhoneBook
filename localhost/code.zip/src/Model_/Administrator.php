<?php

namespace Hillel\Model;

final class Administrator extends User
{
    use WritableArticleTrait;
    use ArticleManageTrait;

    public function ban()
    {

    }

    public function unban()
    {

    }
}
