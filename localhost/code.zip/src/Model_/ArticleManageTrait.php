<?php

namespace Hillel\Model;

trait ArticleManageTrait
{
    public function publish()
    {

    }

    public function unpublish()
    {

    }
}