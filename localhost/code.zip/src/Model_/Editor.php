<?php

namespace Hillel\Model;

final class Editor extends User
{
    use ArticleManageTrait;
}
